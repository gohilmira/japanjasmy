<?php

declare(strict_types=1);

namespace phpseclib3\Exception;

class BadFunctionCallException extends \BadFunctionCallException implements ExceptionInterface
{
}
